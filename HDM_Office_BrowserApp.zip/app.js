
const STORAGE_KEY = "hdm_office_v1";
const defaultState = {
  customers: [],
  orders: [],
  invoices: [],
  payments: [],
  receipts: [],
  settings: {
    companyName: "hout.decoratie.middennederland",
    email: "hout.decoratie.middennederland@hotmail.com",
    phone: "0681526839",
    address: "Patrijzenhof 159, 3755 EP Eemnes",
    vat: "21"
  }
};

let state = loadState();
let currentView = "dashboard";

const view = document.getElementById("view");
const modal = document.getElementById("modal");
const modalTitle = document.getElementById("modalTitle");
const modalBody = document.getElementById("modalBody");
const modalSave = document.getElementById("modalSave");
const pageTitle = document.getElementById("pageTitle");
const sidebar = document.getElementById("sidebar");

document.getElementById("todayText").textContent = new Intl.DateTimeFormat("nl-NL", {
  weekday:"long", day:"numeric", month:"long", year:"numeric"
}).format(new Date());

document.querySelectorAll(".nav-item").forEach(btn=>{
  btn.addEventListener("click",()=>{
    currentView = btn.dataset.view;
    document.querySelectorAll(".nav-item").forEach(b=>b.classList.toggle("active",b===btn));
    pageTitle.textContent = btn.textContent;
    sidebar.classList.remove("open");
    render();
  });
});
document.getElementById("menuBtn").onclick=()=>sidebar.classList.toggle("open");
document.getElementById("quickAddBtn").onclick=()=>openOrderForm();
document.getElementById("exportBtn").onclick=exportBackup;
document.getElementById("importInput").addEventListener("change", importBackup);

function loadState(){
  try{
    const raw=localStorage.getItem(STORAGE_KEY);
    return raw ? {...defaultState,...JSON.parse(raw)} : structuredClone(defaultState);
  }catch(e){ return structuredClone(defaultState); }
}
function saveState(){ localStorage.setItem(STORAGE_KEY,JSON.stringify(state)); render(); }
function euro(n){ return new Intl.NumberFormat("nl-NL",{style:"currency",currency:"EUR"}).format(Number(n||0)); }
function uid(prefix){ return prefix+"-"+Date.now().toString(36)+"-"+Math.random().toString(36).slice(2,6); }
function toast(msg){ const t=document.getElementById("toast"); t.textContent=msg;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),1800); }
function escapeHtml(v=""){ return String(v).replace(/[&<>"']/g,s=>({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#39;"}[s])); }

function render(){
  const map={dashboard:renderDashboard,customers:renderCustomers,orders:renderOrders,invoices:renderInvoices,payments:renderPayments,receipts:renderReceipts,settings:renderSettings};
  map[currentView]();
}

function totals(){
  const revenue=state.invoices.reduce((s,x)=>s+Number(x.total||0),0);
  const costs=state.receipts.reduce((s,x)=>s+Number(x.total||0),0);
  const open=state.invoices.reduce((s,x)=>s+Math.max(0,Number(x.total||0)-Number(x.paid||0)),0);
  const vatOut=state.invoices.reduce((s,x)=>s+Number(x.vat||0),0);
  const vatIn=state.receipts.reduce((s,x)=>s+Number(x.vat||0),0);
  return {revenue,costs,open,vat:vatOut-vatIn,profit:revenue-costs};
}

function renderDashboard(){
  const t=totals();
  const recent=[...state.orders].sort((a,b)=>(b.created||"").localeCompare(a.created||"")).slice(0,5);
  const months=monthlyRevenue();
  view.innerHTML=`
    <div class="grid stats">
      ${stat("Omzet",euro(t.revenue))}
      ${stat("Kosten",euro(t.costs))}
      ${stat("Openstaand",euro(t.open))}
      ${stat("Btw indicatie",euro(t.vat))}
    </div>
    <div class="grid two-col">
      <div class="card">
        <div class="section-head"><h3>Omzet per maand</h3></div>
        <div class="chart">${months.map(m=>`<div class="bar" style="height:${m.height}%"><span>${m.label}</span></div>`).join("")}</div>
      </div>
      <div class="card">
        <div class="section-head"><h3>Snelle acties</h3></div>
        <div class="grid">
          <button class="primary" onclick="openCustomerForm()">Nieuwe klant</button>
          <button class="primary" onclick="openOrderForm()">Nieuwe order</button>
          <button class="primary" onclick="openInvoiceForm()">Nieuwe factuur</button>
          <button class="primary" onclick="openReceiptForm()">Nieuwe bon</button>
        </div>
      </div>
    </div>
    <div class="card" style="margin-top:18px">
      <div class="section-head"><h3>Recente orders</h3><button class="small" onclick="goTo('orders')">Alles bekijken</button></div>
      ${recent.length?orderTable(recent):`<div class="empty">Nog geen orders toegevoegd.</div>`}
    </div>`;
}

function stat(label,value){return `<div class="card stat"><div class="label">${label}</div><div class="value">${value}</div></div>`}
function monthlyRevenue(){
  const fmt=new Intl.DateTimeFormat("nl-NL",{month:"short"});
  const now=new Date(); const rows=[];
  for(let i=5;i>=0;i--){ const d=new Date(now.getFullYear(),now.getMonth()-i,1); const key=d.toISOString().slice(0,7);
    const value=state.invoices.filter(x=>(x.date||"").startsWith(key)).reduce((s,x)=>s+Number(x.total||0),0);
    rows.push({label:fmt.format(d),value});
  }
  const max=Math.max(...rows.map(x=>x.value),1);
  return rows.map(x=>({...x,height:Math.max(8,Math.round((x.value/max)*100))}));
}
function goTo(v){currentView=v;document.querySelectorAll(".nav-item").forEach(b=>b.classList.toggle("active",b.dataset.view===v));pageTitle.textContent=document.querySelector(`[data-view="${v}"]`).textContent;render();}

function renderCustomers(){
  view.innerHTML=`<div class="card"><div class="section-head"><h3>Klanten</h3><button class="primary" onclick="openCustomerForm()">+ Nieuwe klant</button></div>
  ${state.customers.length?`<div class="table-wrap"><table><thead><tr><th>Naam</th><th>Bedrijf</th><th>Telefoon</th><th>E-mail</th><th></th></tr></thead><tbody>
  ${state.customers.map(c=>`<tr><td>${escapeHtml(c.name)}</td><td>${escapeHtml(c.company||"-")}</td><td>${escapeHtml(c.phone||"-")}</td><td>${escapeHtml(c.email||"-")}</td><td class="actions"><button class="small" onclick="openCustomerForm('${c.id}')">Bewerken</button><button class="small" onclick="removeItem('customers','${c.id}')">Verwijderen</button></td></tr>`).join("")}
  </tbody></table></div>`:`<div class="empty">Nog geen klanten toegevoegd.</div>`}</div>`;
}

function orderTable(rows){return `<div class="table-wrap"><table><thead><tr><th>Order</th><th>Klant</th><th>Product</th><th>Oplevering</th><th>Status</th><th>Totaal</th></tr></thead><tbody>${rows.map(o=>`<tr><td>${escapeHtml(o.number)}</td><td>${escapeHtml(customerName(o.customerId))}</td><td>${escapeHtml(o.product)}</td><td>${escapeHtml(o.due||"-")}</td><td><span class="badge">${escapeHtml(o.status)}</span></td><td>${euro(o.total)}</td></tr>`).join("")}</tbody></table></div>`}
function renderOrders(){
  view.innerHTML=`<div class="card"><div class="section-head"><h3>Orders</h3><button class="primary" onclick="openOrderForm()">+ Nieuwe order</button></div>
  ${state.orders.length?`<div class="table-wrap"><table><thead><tr><th>Order</th><th>Klant</th><th>Product</th><th>Oplevering</th><th>Status</th><th>Betaling</th><th>Totaal</th><th></th></tr></thead><tbody>
  ${state.orders.map(o=>`<tr><td>${escapeHtml(o.number)}</td><td>${escapeHtml(customerName(o.customerId))}</td><td>${escapeHtml(o.product)}</td><td>${escapeHtml(o.due||"-")}</td><td><span class="badge">${escapeHtml(o.status)}</span></td><td>${escapeHtml(o.paymentMethod||"-")}</td><td>${euro(o.total)}</td><td class="actions"><button class="small" onclick="openOrderForm('${o.id}')">Bewerken</button><button class="small" onclick="removeItem('orders','${o.id}')">Verwijderen</button></td></tr>`).join("")}
  </tbody></table></div>`:`<div class="empty">Nog geen orders toegevoegd.</div>`}</div>`;
}

function renderInvoices(){
  view.innerHTML=`<div class="card"><div class="section-head"><h3>Facturen</h3><button class="primary" onclick="openInvoiceForm()">+ Nieuwe factuur</button></div>
  ${state.invoices.length?`<div class="table-wrap"><table><thead><tr><th>Factuur</th><th>Klant</th><th>Datum</th><th>Totaal</th><th>Betaald</th><th>Open</th><th></th></tr></thead><tbody>
  ${state.invoices.map(i=>{const open=Math.max(0,Number(i.total)-Number(i.paid||0));return `<tr><td>${escapeHtml(i.number)}</td><td>${escapeHtml(customerName(i.customerId))}</td><td>${escapeHtml(i.date)}</td><td>${euro(i.total)}</td><td>${euro(i.paid)}</td><td><span class="badge ${open===0?'success':'warn'}">${euro(open)}</span></td><td class="actions"><button class="small" onclick="openInvoiceForm('${i.id}')">Bewerken</button><button class="small" onclick="removeItem('invoices','${i.id}')">Verwijderen</button></td></tr>`}).join("")}
  </tbody></table></div>`:`<div class="empty">Nog geen facturen toegevoegd.</div>`}</div>`;
}

function renderPayments(){
  view.innerHTML=`<div class="card"><div class="section-head"><h3>Betalingen</h3><button class="primary" onclick="openPaymentForm()">+ Betaling registreren</button></div>
  ${state.payments.length?`<div class="table-wrap"><table><thead><tr><th>Datum</th><th>Klant</th><th>Methode</th><th>Bedrag</th><th>Notitie</th><th></th></tr></thead><tbody>
  ${state.payments.map(p=>`<tr><td>${escapeHtml(p.date)}</td><td>${escapeHtml(customerName(p.customerId))}</td><td>${escapeHtml(p.method)}</td><td>${euro(p.amount)}</td><td>${escapeHtml(p.note||"-")}</td><td><button class="small" onclick="removeItem('payments','${p.id}')">Verwijderen</button></td></tr>`).join("")}
  </tbody></table></div>`:`<div class="empty">Nog geen betalingen geregistreerd.</div>`}</div>`;
}

function renderReceipts(){
  view.innerHTML=`<div class="card"><div class="section-head"><h3>Bonnen en inkoopfacturen</h3><button class="primary" onclick="openReceiptForm()">+ Nieuwe bon</button></div>
  ${state.receipts.length?`<div class="table-wrap"><table><thead><tr><th>Datum</th><th>Leverancier</th><th>Categorie</th><th>Totaal</th><th>Btw</th><th>Bestand</th><th></th></tr></thead><tbody>
  ${state.receipts.map(r=>`<tr><td>${escapeHtml(r.date)}</td><td>${escapeHtml(r.supplier)}</td><td>${escapeHtml(r.category)}</td><td>${euro(r.total)}</td><td>${euro(r.vat)}</td><td>${escapeHtml(r.fileName||"-")}</td><td><button class="small" onclick="removeItem('receipts','${r.id}')">Verwijderen</button></td></tr>`).join("")}
  </tbody></table></div>`:`<div class="empty">Nog geen bonnen toegevoegd.</div>`}</div>`;
}

function renderSettings(){
  const s=state.settings;
  view.innerHTML=`<div class="card"><div class="section-head"><h3>Bedrijfsinstellingen</h3></div>
  <div class="form-grid">
  ${field("Bedrijfsnaam",`<input id="setCompany" value="${escapeHtml(s.companyName)}">`)}
  ${field("E-mail",`<input id="setEmail" value="${escapeHtml(s.email)}">`)}
  ${field("Telefoon",`<input id="setPhone" value="${escapeHtml(s.phone)}">`)}
  ${field("Standaard btw",`<select id="setVat"><option ${s.vat==="21"?"selected":""}>21</option><option ${s.vat==="9"?"selected":""}>9</option><option ${s.vat==="0"?"selected":""}>0</option></select>`)}
  ${field("Adres",`<textarea id="setAddress">${escapeHtml(s.address)}</textarea>`,"full")}
  </div><div style="margin-top:16px"><button class="primary" onclick="saveSettings()">Instellingen opslaan</button></div></div>`;
}
function field(label,control,cls=""){return `<div class="field ${cls}"><label>${label}</label>${control}</div>`}
function customerName(id){return state.customers.find(c=>c.id===id)?.name || "Onbekend";}

function openModal(title,body,onSave){modalTitle.textContent=title;modalBody.innerHTML=body;modalSave.onclick=onSave;modal.showModal();}
function openCustomerForm(id){
  const x=state.customers.find(c=>c.id===id)||{};
  openModal(id?"Klant bewerken":"Nieuwe klant",`<div class="form-grid">
  ${field("Naam",`<input id="fName" value="${escapeHtml(x.name||"")}">`)}
  ${field("Bedrijf",`<input id="fCompany" value="${escapeHtml(x.company||"")}">`)}
  ${field("Telefoon",`<input id="fPhone" value="${escapeHtml(x.phone||"")}">`)}
  ${field("E-mail",`<input id="fEmail" type="email" value="${escapeHtml(x.email||"")}">`)}
  ${field("Adres",`<textarea id="fAddress">${escapeHtml(x.address||"")}</textarea>`,"full")}
  </div>`,()=>{
    const name=v("fName"); if(!name)return toast("Vul een naam in.");
    const obj={id:id||uid("cus"),name,company:v("fCompany"),phone:v("fPhone"),email:v("fEmail"),address:v("fAddress")};
    upsert("customers",obj);modal.close();toast("Klant opgeslagen.");
  });
}

function customerOptions(selected=""){return `<option value="">Kies klant</option>${state.customers.map(c=>`<option value="${c.id}" ${selected===c.id?"selected":""}>${escapeHtml(c.name)}</option>`).join("")}`}

function openOrderForm(id){
  const x=state.orders.find(o=>o.id===id)||{};
  const nr=x.number||`HDM-${new Date().getFullYear()}-${String(state.orders.length+1).padStart(3,"0")}`;
  openModal(id?"Order bewerken":"Nieuwe order",`<div class="form-grid">
  ${field("Ordernummer",`<input id="oNumber" value="${escapeHtml(nr)}">`)}
  ${field("Klant",`<select id="oCustomer">${customerOptions(x.customerId)}</select>`)}
  ${field("Product",`<input id="oProduct" value="${escapeHtml(x.product||"")}">`)}
  ${field("Opleverdatum",`<input id="oDue" type="date" value="${escapeHtml(x.due||"")}">`)}
  ${field("Totaalbedrag",`<input id="oTotal" type="number" step="0.01" value="${escapeHtml(x.total||"")}">`)}
  ${field("Aanbetaling",`<input id="oDeposit" type="number" step="0.01" value="${escapeHtml(x.deposit||"")}">`)}
  ${field("Betaalmethode",`<select id="oMethod">${["Tikkie","Contant","Bank","Pin","Nog niet betaald"].map(m=>`<option ${x.paymentMethod===m?"selected":""}>${m}</option>`).join("")}</select>`)}
  ${field("Status",`<select id="oStatus">${["Nieuw","In productie","Schilderen","Klaar","Afgehaald","Bezorgd"].map(m=>`<option ${x.status===m?"selected":""}>${m}</option>`).join("")}</select>`)}
  ${field("Afmetingen / kleur / notities",`<textarea id="oNotes">${escapeHtml(x.notes||"")}</textarea>`,"full")}
  </div>`,()=>{
    if(!v("oProduct"))return toast("Vul een product in.");
    const obj={id:id||uid("ord"),number:v("oNumber"),customerId:v("oCustomer"),product:v("oProduct"),due:v("oDue"),total:v("oTotal"),deposit:v("oDeposit"),paymentMethod:v("oMethod"),status:v("oStatus"),notes:v("oNotes"),created:x.created||new Date().toISOString()};
    upsert("orders",obj);modal.close();toast("Order opgeslagen.");
  });
}

function openInvoiceForm(id){
  const x=state.invoices.find(i=>i.id===id)||{};
  const nr=x.number||`${new Date().getFullYear()}-${String(state.invoices.length+1).padStart(3,"0")}`;
  openModal(id?"Factuur bewerken":"Nieuwe factuur",`<div class="form-grid">
  ${field("Factuurnummer",`<input id="iNumber" value="${escapeHtml(nr)}">`)}
  ${field("Klant",`<select id="iCustomer">${customerOptions(x.customerId)}</select>`)}
  ${field("Datum",`<input id="iDate" type="date" value="${escapeHtml(x.date||new Date().toISOString().slice(0,10))}">`)}
  ${field("Totaal incl. btw",`<input id="iTotal" type="number" step="0.01" value="${escapeHtml(x.total||"")}">`)}
  ${field("Btw bedrag",`<input id="iVat" type="number" step="0.01" value="${escapeHtml(x.vat||"")}">`)}
  ${field("Reeds betaald",`<input id="iPaid" type="number" step="0.01" value="${escapeHtml(x.paid||"")}">`)}
  ${field("Omschrijving",`<textarea id="iDescription">${escapeHtml(x.description||"")}</textarea>`,"full")}
  </div>`,()=>{
    if(!v("iTotal"))return toast("Vul het totaalbedrag in.");
    const obj={id:id||uid("inv"),number:v("iNumber"),customerId:v("iCustomer"),date:v("iDate"),total:v("iTotal"),vat:v("iVat"),paid:v("iPaid"),description:v("iDescription")};
    upsert("invoices",obj);modal.close();toast("Factuur opgeslagen.");
  });
}

function openPaymentForm(){
  openModal("Betaling registreren",`<div class="form-grid">
  ${field("Klant",`<select id="pCustomer">${customerOptions()}</select>`)}
  ${field("Datum",`<input id="pDate" type="date" value="${new Date().toISOString().slice(0,10)}">`)}
  ${field("Methode",`<select id="pMethod"><option>Tikkie</option><option>Contant</option><option>Bank</option><option>Pin</option></select>`)}
  ${field("Bedrag",`<input id="pAmount" type="number" step="0.01">`)}
  ${field("Notitie",`<textarea id="pNote"></textarea>`,"full")}
  </div>`,()=>{
    if(!v("pAmount"))return toast("Vul een bedrag in.");
    state.payments.push({id:uid("pay"),customerId:v("pCustomer"),date:v("pDate"),method:v("pMethod"),amount:v("pAmount"),note:v("pNote")});
    saveState();modal.close();toast("Betaling opgeslagen.");
  });
}

function openReceiptForm(){
  openModal("Nieuwe bon of inkoopfactuur",`<div class="form-grid">
  ${field("Datum",`<input id="rDate" type="date" value="${new Date().toISOString().slice(0,10)}">`)}
  ${field("Leverancier",`<input id="rSupplier">`)}
  ${field("Categorie",`<select id="rCategory"><option>Materialen</option><option>Gereedschap en machines</option><option>Software en abonnementen</option><option>Huur en opslag</option><option>Marketing</option><option>Transport</option><option>Overig</option></select>`)}
  ${field("Totaal incl. btw",`<input id="rTotal" type="number" step="0.01">`)}
  ${field("Btw bedrag",`<input id="rVat" type="number" step="0.01">`)}
  ${field("Foto of PDF",`<input id="rFile" type="file" accept="image/*,.pdf">`,"full")}
  </div>`,()=>{
    if(!v("rSupplier")||!v("rTotal"))return toast("Vul leverancier en totaalbedrag in.");
    const file=document.getElementById("rFile").files[0];
    state.receipts.push({id:uid("rec"),date:v("rDate"),supplier:v("rSupplier"),category:v("rCategory"),total:v("rTotal"),vat:v("rVat"),fileName:file?.name||""});
    saveState();modal.close();toast("Bon opgeslagen.");
  });
}

function v(id){return document.getElementById(id)?.value?.trim()||""}
function upsert(type,obj){const i=state[type].findIndex(x=>x.id===obj.id);if(i>=0)state[type][i]=obj;else state[type].push(obj);saveState();}
function removeItem(type,id){if(confirm("Weet je zeker dat je dit wilt verwijderen?")){state[type]=state[type].filter(x=>x.id!==id);saveState();toast("Verwijderd.");}}
function saveSettings(){state.settings={companyName:v("setCompany"),email:v("setEmail"),phone:v("setPhone"),address:v("setAddress"),vat:v("setVat")};saveState();toast("Instellingen opgeslagen.");}

function exportBackup(){
  const blob=new Blob([JSON.stringify(state,null,2)],{type:"application/json"});
  const a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download=`hdm-office-backup-${new Date().toISOString().slice(0,10)}.json`;a.click();URL.revokeObjectURL(a.href);
}
function importBackup(e){
  const file=e.target.files[0];if(!file)return;
  const reader=new FileReader();reader.onload=()=>{try{state=JSON.parse(reader.result);saveState();toast("Back-up geïmporteerd.");}catch{toast("Ongeldig back-upbestand.");}};reader.readAsText(file);
}
if("serviceWorker" in navigator){window.addEventListener("load",()=>navigator.serviceWorker.register("sw.js").catch(()=>{}));}
render();
