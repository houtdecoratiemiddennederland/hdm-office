# HDM Office

Werkende browser-app voor hout.decoratie.middennederland.

## Inhoud
- Dashboard
- Klanten
- Orders
- Facturen
- Betalingen
- Bonnen en inkoopfacturen
- Instellingen
- Lokale opslag in de browser
- Back-up export en import
- PWA/offline ondersteuning

## Publiceren via Vercel
1. Maak een gratis account op Vercel.
2. Kies **Add New Project**.
3. Upload deze map of koppel een GitHub-repository.
4. Er is geen build command nodig.
5. Publiceer het project.

## Publiceren via GitHub Pages
1. Maak een nieuwe GitHub-repository.
2. Upload alle bestanden uit deze map.
3. Ga naar **Settings > Pages**.
4. Kies **GitHub Actions** als bron.
5. De meegeleverde workflow publiceert de app automatisch.

## Belangrijk
Deze versie gebruikt lokale browseropslag. Gegevens synchroniseren niet automatisch tussen apparaten.
Foto's en PDF's worden nog niet fysiek opgeslagen; alleen de bestandsnaam wordt geregistreerd.
Voor veilig inloggen, cloudopslag en synchronisatie is later een database nodig.
